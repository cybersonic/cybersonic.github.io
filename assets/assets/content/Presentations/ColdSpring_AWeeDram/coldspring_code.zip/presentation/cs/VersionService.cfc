<cfcomponent output="false">

	<cffunction name="init" access="public" output="false">
		<cfargument name="OrmService">
			<cfset variables.ormservice = arguments.ormservice>	
		
		<cfreturn this/>
	</cffunction>



	<cffunction name="saveVersion" output="false" access="public">
		<cfargument name="objecttype">
		<cfargument name="objectid">
		<cfargument name="objectwddx">
		
		<cfscript>
			var	oVersion = variables.ormservice.createRecord("version")
							.setObjectType(arguments.objecttype)
							.setObjectId(arguments.objectid)
							.setContent(arguments.objectwddx)
							.save();		
		</cfscript>
		
		
	</cffunction>

</cfcomponent>