<!--- 
	Saves the document
	
 --->

<cfparam name="form.id" default="0">
<cfparam name="form.name" default="">
<cfparam name="form.content" default="">

<cfset bf = application.myBeanFactory>

<cfset DocS = bf.getBean("DocumentService")>

<cfset DocS.save(form.id,form.name,form.content)>



Saved the document! 
<cfdump var="#DocS.load(form.id)._getTO()#">