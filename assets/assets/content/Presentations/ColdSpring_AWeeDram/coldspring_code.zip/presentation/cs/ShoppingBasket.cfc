<cfcomponent output="false">
	
	<cfset this.uuid = CreateUUID()>
	<cfset this.totalPrice = "150">
	
<cffunction name="init" returnType="Any" output="false">
	<cfargument name="MaxItems" type="numeric">
	<cfargument name="TaxCalculator" type="TaxCalculator">
	<!--- We are expecting a configured Tax Calculator --->
	<cfset this.TaxCalculator = arguments.TaxCalculator>
	<!--- Set the local variable --->
	<cfset this.MaxItems = arguments.MaxItems>
	<cfreturn this/>
</cffunction>

<cffunction name="getTotalPrice" returntype="numeric" output="false">
	<cfreturn this.totalPrice>
</cffunction>

<cffunction name="getTax" returntype="numeric" output="false">
	<cfreturn this.TaxCalculator.calculate(getTotalPrice())>

</cffunction>


</cfcomponent>