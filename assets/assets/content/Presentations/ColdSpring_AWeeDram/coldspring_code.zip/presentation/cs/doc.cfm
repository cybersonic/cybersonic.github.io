<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>Edit Document</title>
		<cfsilent>
			<cfparam name="url.id" default="0">		
			<cfset bf = application.myBeanFactory>

			<cfset DocS = bf.getBean("DocumentService")>
			<cfset oDoc = DocS.load(url.id)>
		
		</cfsilent>
	</head>
	<body>		
		<cfform action="savedoc.cfm" method="post">
			<cfinput type="hidden" name="id" value="#oDoc.getID()#">
			<cfinput type="text" name="name" value="#oDoc.getName()#" size="100">
			<cftextarea name="content" richtext="true" toolbar="Basic" value="#oDoc.getContent()#" />
			<cfinput type="submit" id="btnSave" name="btnSave" value="Save"/>
		</cfform>
	</body>
</html>
