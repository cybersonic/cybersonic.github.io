<cfset bf = application.myBeanFactory>

<cfset myBskt = bf.getBean("ShoppingBasket")>


<cfdump var="#myBskt#">
<cfoutput><ul>
	<li>BasketID : #myBskt.UUID#</li>
	<li>TaxCalcID : #myBskt.TaxCalculator.UUID#</li>
</ul></cfoutput>

<cfdump var="#myBskt.getTax()#">

<cfif bf.containsBean("DocumentService")>
<a href="listdocs.cfm">List Documents</a>

</cfif>

<cfif bf.containsBean("remoteLanguageService")>
<a href="webservice.cfm">Get Document Via WebService</a>
</cfif>