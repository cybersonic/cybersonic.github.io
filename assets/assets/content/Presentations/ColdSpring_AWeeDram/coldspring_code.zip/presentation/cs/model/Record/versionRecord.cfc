
<cfcomponent hint="I am the database agnostic custom Record object for the version object.  I am generated, but not overwritten if I exist.  You are safe to edit me."
	extends="reactor.project.CSDemo.Record.versionRecord" >
	<!--- Place custom code here, it will not be overwritten --->
	
</cfcomponent>
	
