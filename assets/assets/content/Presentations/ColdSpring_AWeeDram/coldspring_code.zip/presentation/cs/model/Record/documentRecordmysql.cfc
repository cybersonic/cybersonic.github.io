
<cfcomponent hint="I am the mysql custom Record object for the document object.  I am generated, but not overwritten if I exist.  You are safe to edit me."
	extends="documentRecord" >
	<!--- Place custom code here, it will not be overwritten --->
		
</cfcomponent>
	
