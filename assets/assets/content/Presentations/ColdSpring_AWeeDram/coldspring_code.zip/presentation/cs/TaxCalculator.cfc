<cfcomponent output="false">
	<cfset this.uuid = CreateUUID()>
	<cfset this.taxRate = "1">

	<cffunction name="init" returntype="any" output="false">
		<cfargument name="TaxRate" type="numeric">
		<cfset this.TaxRate = arguments.TaxRate>
		<cfreturn this/>
	</cffunction>


	<cffunction name="calculate" returntype="numeric" output="false">
		<cfargument name="Figure" type="numeric">
	
	
		<cfreturn arguments.Figure * this.TaxRate>
	</cffunction>


</cfcomponent>