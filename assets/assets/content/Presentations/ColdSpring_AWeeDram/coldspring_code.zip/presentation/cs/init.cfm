<!--- Create a bean factory 			--->
<cfset application.myBeanFactory = CreateObject("component", 
			"coldspring.beans.DefaultXmlBeanFactory").init()>

<!--- As a Path --->			 
<cfset application.myBeanFactory
		.loadBeansFromXmlFile(expandPath("Coldspring.xml") , true)>	

 					

<!--- As a raw xml string
<cfsavecontent variable="beanConfig">
<beans>
	<!-- define the Tax Calculator -->
	<bean id="TaxCalculator" class="presentation.cs.TaxCalculator">
		<constructor-arg name="TaxRate">
			<value>1.175</value>
		</constructor-arg>
	</bean>
	
	<bean id="ShoppingBasket" 
		  class="presentation.cs.ShoppingBasket" singleton="false">
		  <constructor-arg name="MaxItems"><value>10</value></constructor-arg>
		  <constructor-arg name="TaxCalculator">
		  	<ref bean="TaxCalculator" />
		  </constructor-arg>
	</bean>
		  
</beans>
</cfsavecontent>
<cfset application.myBeanFactory.loadBeansFromXmlRaw(beanConfig
					, true)>	

 --->
<!--- As an XML object 
<cffile action ="read" file="#expandPath("Coldspring.xml")#"
		variable="xmlContent">
		<cfset beanXML = XMLParse(xmlContent)>
		<cfdump var="#beanXML#">
		
<cfset application.myBeanFactory.loadBeansFromXmlObj(beanXML
					, true)>
--->
					
					
	