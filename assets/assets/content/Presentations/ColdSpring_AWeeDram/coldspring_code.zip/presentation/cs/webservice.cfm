
<!--- 
	Had to remove the tools.jar for this to work
	see: http://www.adobe.com/cfusion/webforums/forum/messageview.cfm?catid=3&threadid=1289245

 --->
<cfset ws = CreateObject("webservice", "http://localhost/presentation/cs/RemoteDocumentService.cfc?wsdl")>
<cfdump var="#ws.load(2,true)#">