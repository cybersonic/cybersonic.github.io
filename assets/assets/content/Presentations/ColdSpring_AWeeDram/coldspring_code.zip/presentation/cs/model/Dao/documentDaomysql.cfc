
<cfcomponent hint="I am the mysql custom DAO object for the document object.  I am generated, but not overwritten if I exist.  You are safe to edit me."
	extends="documentDao" >
	<!--- Place custom code here, it will not be overwritten --->
</cfcomponent>
	
