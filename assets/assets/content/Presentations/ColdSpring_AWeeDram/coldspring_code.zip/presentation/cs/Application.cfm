<cfapplication name="CSDemo#hash(getCurrentTemplatePath())#" >
<cfsilent>
	<cfif Not isDefined("application.myBeanFactory")>
		<cfinclude template="init.cfm">
	</cfif>
	
	<!--- Reload it =when I want it --->
	<cfif StructKeyExists(URL, "init")>
		<cfinclude template="init.cfm">
	</cfif>
	
	
</cfsilent>