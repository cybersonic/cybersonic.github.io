

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>List Documents</title>
		<cfsilent>
			<cfset bf = application.myBeanFactory>
			<cfset re = bf.getBean("ReactorFactory")>
			<cfset qDocs = re.createGateway("document").getAll()>
		</cfsilent>
	</head>
	<body>		



<cfloop query="qDocs">
	
<cfoutput>	<li><a href="doc.cfm?id=#qDocs.id#">#qDocs.name#</li></cfoutput>

</cfloop>
</ul>

	</body>
</html>
