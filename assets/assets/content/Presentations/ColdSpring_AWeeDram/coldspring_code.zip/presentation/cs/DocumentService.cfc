<cfcomponent output="false">
<!--- 
	Sample service that saves a bit of string
 --->

	<cffunction name="init" access="public" output="false">
		<cfargument name="OrmService">
			<cfset variables.ormservice = arguments.ormservice>	
		
		<cfreturn this/>
	</cffunction>



	<cffunction name="save" access="public" output="false">
		<cfargument name="id" default="0">
		<cfargument name="name" default="">
		<cfargument name="content" default="">
	
		<cfscript>
			var oDoc = variables.ormService.createRecord("document")
							.setID(arguments.id)
							.setName(arguments.name)
							.setContent(arguments.content)
							.save();
		
		</cfscript>
		
	</cffunction>
	
	<cffunction name="load" access="public" output="false">
		<cfargument name="id" default="0" type="numeric">
		<cfargument name="asTO" default="false" type="boolean">
		
		<cfif arguments.asTO>
			<cfset obj = variables.ormService.createRecord("document").load(id=arguments.id)._getTO()>
			<cfset currDocumentStruct = {}>
			
			<cfloop collection="#obj#" item="prop">
				<cfif isSimpleValue(obj[prop])>
					<cfset StructInsert(currDocumentStruct, prop, obj[prop])>
				</cfif>
			</cfloop>
			
			<cfreturn currDocumentStruct />
		</cfif>
		<cfscript>
			return variables.ormService.createRecord("document").load(id=arguments.id);
		</cfscript>
	</cffunction>
	
</cfcomponent>