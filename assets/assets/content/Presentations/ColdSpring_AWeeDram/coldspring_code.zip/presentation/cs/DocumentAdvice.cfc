<cfcomponent output="false" extends="coldspring.aop.BeforeAdvice">

	<cffunction name="init" output="false" access="public">
			<cfargument name="versionService">
			<cfargument name="ormService">
			<cfset variables.versionService = arguments.versionService>
			<cfset variables.ormService = arguments.ormService>
			
		<cfreturn this/>
	</cffunction>
	
	<cffunction name="before" returntype="any" access="public" output="false" hint="">  
        <cfargument name="method" type="coldspring.aop.Method">
		<cfargument name="args" type="struct">
		<cfargument name="target" type="any">
		
			<cfif arguments.method.getMethodName() NEQ "save">
				<cfreturn />
			</cfif>

			<cfif NOT StructKeyExists(arguments.args, "ID")>
				<cfthrow message="ID is required">
			</cfif>
				
			<cfset currDocument = variables.ormservice.createRecord("Document").load(id=arguments.args.ID)._getTO()>
			
			<cfset currDocumentStruct = {}>
			
			<cfloop collection="#currDocument#" item="prop">
				<cfif isSimpleValue(currDocument[prop])>
					<cfset StructInsert(currDocumentStruct, prop, currDocument[prop])>
				</cfif>
			</cfloop>
			
			<cfwddx action="cfml2wddx" input="#currDocumentStruct#" output="currDocumentWDDX">
			
			<cfset variables.versionService.saveVersion("document", args.ID, currDocumentWDDX)>
			
     </cffunction> 
</cfcomponent>