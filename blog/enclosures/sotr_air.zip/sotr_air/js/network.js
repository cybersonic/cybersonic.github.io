/**
 * @author markdrew
 */

var monitor = "";
$(document).ready(function(){
	
	var request = new air.URLRequest( 'http://www.twitter.com' );
	
	monitor = new air.URLMonitor( request );
	monitor.addEventListener( air.StatusEvent.STATUS, doStatus );
	monitor.start();
	
	
	function doStatus(event){
		if(monitor.available){
			$("#statusMessges").text("Service available");
			//Show the connected icon
			
			$("#connection_status").addClass("connection_status_on");			
			sendOffLineMessages();
		}
		else{
			$("#statusMessges").text("No service");
			$("#connection_status").addClass("connection_status_off");			
		}
	}
	
	function sendOffLineMessages(){
		var queueDir = air.File.applicationStorageDirectory.resolvePath( "queue");
		var files = queueDir.getDirectoryListing();
		var elem = null;
		var name = null;
		var mod = null;
		var size = null;
		
		for( var f = 0; f < files.length; f++ )
		{
			name = files[f].name;
			
			mod = files[f].modificationDate;
			mod = ( mod.month + 1 ) + '/' + mod.date + '/' + mod.fullYear;
			size = Math.ceil( files[f].size / 1000 ) + ' KB';		
			var sendMsg =  confirm("Send the following message? \n" + loadFile("queue/" + name));
			if(sendMsg){
				//we send the message and then delete it
				sendStatus(loadFile("queue/" + name));
			}
			
//			var delmsg = air.File.applicationStorageDirectory.resolvePath( "queue/" + name);
//			delmsg.deleteFile();
		}
}
});