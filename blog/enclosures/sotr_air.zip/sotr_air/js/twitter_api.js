/**
 * @author markdrew
 * 	public timeline: http://twitter.com/statuses/public_timeline.json
 * friends timeline: http://twitter.com/statuses/friends_timeline.json
				
 * 
 */


var lastMessageID = "";
var lastUpdate = Date();
var reloadWait = 30000;
$(document).ready(function(){
	//When we are started lets load our timeline
	getFriendsTimeline();
	


	var timer = setInterval(getFriendsTimeline, reloadWait);	
	
	$("#btnSend").click(sendStatusProxy);
	
	$("#status_field").bind("keyup", function(e){
			var chars = $("#status_field").val().length;
			var total = 140 - chars;
			$("#status_chars").text(total);

		});
	$("#refresh").click(getFriendsTimeline);
});

	function getPublicTimeline(){
		return getTimeline("public");
	}
 	
	function getFriendsTimeline(){
		return getTimeline("friends");
	}
 function getTimeline(timelineType){
 	var timelineURL = "http://twitter.com/statuses/";
 	var timelineFormat = "json";
	
	var reqTimeline = timelineURL + timelineType + '_timeline.' + timelineFormat;
	
	$.ajax({
		url: reqTimeline,
		dataType: timelineFormat,
		beforeSend: function(req){
			$("#loader").show();
			$("#statusMessges").text("Loading timeline...");
		},
		success: handleTimeline,
		error: function(XMLHttpRequest, textStatus, errorThrown){
						$("#loader").hide();
						$("#statusMessges").text("Failed to load timeline" + textStatus);
				
		}
	});
			
 }
 
 
 /**
  * Display the results of the timeline changing
  * @param {Object} result
  */
 function handleTimeline(result){
 	
 	var timelinechanged = false;
	//Check whether the first item is different...i.e. has the timeline changed?
	if(result[0] && result[0].id != lastMessageID){
		timelinechanged = true;
		lastMessageID = result[0].id;
		lastUpdate = Date();
	}
	
	if(timelinechanged){
		//Clear the timeline
		$("#content").empty();
		//Loop through the items statii
		$(result).each(function(item){
			var rowmod = item % 2;
			//render this row
			$("#content").append(
				renderEntry(rowmod, this.user.profile_image_url, this.user.screen_name, this.text)
			);
		});
		addReplyHandlers();
		//since the timeline has changed, lets notify
		air.NativeApplication.nativeApplication.icon.bounce();
	}
		lastUpdate = getFormattedDate();
	$("#statusMessges").text("Last Updated: " + lastUpdate);
 }


 function sendStatusProxy(){
 	sendStatus($("#status_field").val())
 }
 
 function sendStatus(inputMessage){
 		var msg = inputMessage;
		
		if(msg.length == 0){
			return;
		}
		
	
	 	if(!monitor.available){
			//Update the status
				$("#statusMessges").text("Saving status, will send it later");
				saveMessage(msg);
				$("#status_field").val("");
				return;
		}
			
			$("#statusMessges").text("Sending status...");
			$.ajax({
				url: "http://twitter.com/statuses/update.json",
				
				//beforeSend: function(req){
				//	req.setRequestHeader("Authorization", encHeader);
				//},
				type: "POST",
				data: "status=" + msg + "&source=tair",
				success: function(ret){
					$("#status_field").val("");
					$("#statusMessges").text("Satus updated");
					//Reload the timeline
					getFriendsTimeline();
					
				}
			});
 }
 
 function addReplyHandlers(){
 	$(".reply").each(function(item){
		$(this).click(function(){
			var replyText = "@" + $(this).attr("userid") + ": ";
			$("#status_field").focus();
			$("#status_field").val(replyText);
		});
	});
	
 }
 
 function saveMessage(msg){
	//Check that the queue directory exists
	var queueDir = air.File.applicationStorageDirectory.resolvePath( "queue" );
	if(!queueDir.exists){
		air.trace("Queue Directory doesnt exist, creating");
		queueDir.createDirectory();
	}
	//Create the file name
	var dt = new Date();
	var filename = "" + dt.getFullYear() + dt.getMonth() + dt.getDay()+dt.getHours()+dt.getMinutes() + dt.getSeconds()+dt.getMilliseconds() + ".msg";
	air.trace(filename);
	
	//Now we save the file
	saveFile("queue/" + filename, msg);
}


function getFormattedDate(){
	var d = new Date()
	var dd = d.getDate();
	var mm = d.getMonth();
	var yy = d.getFullYear();
	var hrs = d.getHours();
	var mins = d.getMinutes();
	if(mins < 10){
		mins = "0" + mins;
	}
	if(hrs < 10){
		hrs = "0" + hrs;
	}
	var formattedDate = dd + "/" + mm + "/" + yy + " " + hrs + ":" + mins;
	return formattedDate;
}


