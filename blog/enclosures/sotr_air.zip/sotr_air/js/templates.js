/**
 * @author markdrew
 * This file contains all the templates for content
 * requires: 
 */


function renderEntry(id, image, user, message){
	var msg = '<div class="row' + id + '">' +
				'<div class="friend_image"><img src="' + image + '" /></div>' +
				'<div>' + user + ': ' + message+ '</div>' +
				'<div class="clearboth"/>' +
				'<div class="msgControls">' +
				'	<div class="reply" id="reply_' + user + '" userid="'+ user +'"></div>' +
				'	<div class="direct" id="direct_' + user + '"></div>' +
				'</div>';
	return msg;			
}
