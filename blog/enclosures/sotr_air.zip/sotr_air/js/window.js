/**
 * @author markdrew
 */
$(document).ready(function(){
	
	
	var onMove = function(event){
	    nativeWindow.startMove();
	}
	function doClose(){
		var closing = new air.Event(air.Event.CLOSING, true, true);
	    window.nativeWindow.dispatchEvent(closing);
	    if(!closing.isDefaultPrevented()){
	        nativeWindow.close();
	    }
	} 
	
	var doMini = function(event){
		window.nativeWindow.minimize();
	}
	
	var onResize = function(event){
		  window. nativeWindow.startResize(air.NativeWindowResize.BOTTOM_RIGHT);
	}
	
	
	$("#header").bind("mousedown", onMove);
	$("#close").bind("click", doClose);
	$("#minimise").bind("click", doMini);
	
	
	
	//$("#resize").bind("mousedown", onResize);
	
});