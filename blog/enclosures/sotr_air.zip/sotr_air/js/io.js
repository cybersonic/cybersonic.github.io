/**
 * @author markdrew
 */


	function saveFile(filename, contents){
		var file = air.File.applicationStorageDirectory.resolvePath( filename );
		var stream = new air.FileStream();
		stream.open( file, air.FileMode.WRITE );
		stream.writeMultiByte( contents, air.File.systemCharset );
		stream.close();
	}
	
	//Load file
	function loadFile(filename){
	    var f = air.File.applicationStorageDirectory.resolvePath(filename);
	    var fs = new air.FileStream();
	    fs.open(f, air.FileMode.READ);
	    var content = fs.readUTFBytes(fs.bytesAvailable);
	    fs.close();
	    return content;
	}
